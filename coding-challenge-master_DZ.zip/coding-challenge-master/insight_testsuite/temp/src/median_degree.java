// example of program that calculates the  median degree of a 
// venmo transaction graph
