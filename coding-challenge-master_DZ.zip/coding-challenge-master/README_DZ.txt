Written by Danylo Zherebetskyy in Python on July 11,2016
for Insight Data Engineering - Coding Challenge

Requires to import 
sys, os, json, datetime and numpy

Works with data up to 1GB

Cons:  -code is not dynamic - does not work with the constantly updating input
       -for large data >1GB may require a lot of RAM

Possible solution: write using iterative IJSON 





